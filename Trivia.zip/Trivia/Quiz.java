/**
 * @(#)Quiz.java
 *
 *
 * @author Pamisa, Juicely ORG
 * @version 1.00 2019/3/2
 */
import javax.swing.JOptionPane;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.event.*;  //defines event handlers

public class Quiz extends JFrame implements ActionListener{
        
    JLabel img, picT, pics,lblP,lblTitle,lblR,lblS,lblBg,lblE, lblIns,lblTri, lblTries, lblCor, lblOff;
    JButton b1, b2, b3, b4, b5, b6, bNG, bIns, bQuit, bStart; //bNext, bCheck
    JTextField txtS, txtpic;
    JTextArea  txtQuest;
   // String ba1="locked", ba2="locked", ba3="locked", ba4="locked", ba5="locked", ba6="locked";
    String bb1="green", bb2="green", bb3="green", bb4="green", bb5="green", bb6="green";
    String [] Ans = new String[6];
    String list;
    String listA;
    JFrame frame = new JFrame();
   	JFrame f = new JFrame("Animation"); 
    int amount;
    int money = 0;
    Random r = new Random();
    String doneQuestion = "";
    String CorrectAnswer;
    String userAnswer;
    int checkPerQuiz = 0;
    int moneyCounter = 0;
    
    String Money[] = {"50,000","30,000","20,000","60,000","10,000","40,000","70,000","80,000"};
    
    String Questions[] = {"Food: \n What are the unhealthy foods?", 
        						"Food: \n What are the healthy foods?",
        						"Food: \n What are the sweet foods? Except one", 
        						"National: \n Who are the President of the Philippines?",
        					
        						"Animals: \n What are the animals that have fur?",
        						"Brand: \n What are the laptop brands?",
        						"Anatomy: \n What are the five senses humans have?"};
        						
    String Answers[]={"Soda,Chips,Corniks,Liquor,Candy,Veggies",
        					"Milk,Eggs,Breads,Carrots,Peanuts,Soda",
        					"Candy,Yogurt,Sugar,Chocolate,Gummies,Sweetcorn",
        					"Villiar,Duterte,Arroyo,Marcos,Erap,Aquino",
        					
        					"Dog,Cat,Mouse,Crocs,Squerrel,Birds",
        					"Asus,Lenovo,HP,Dell,MSI,DelMonte",
        					"Sight,Hear,Smell,Taste,Fart,Touch"};
        					
    String CorrectAnswers[]={"Soda,Chips,Corniks,Candy,Liquor",
    						"Milk,Eggs,Breads,Peanuts,Carrots",
    						"Candy,Sugar,Chocolate,Gummies,Sweetcorn",
        					"Duterte,Arroyo,Marcos,Erap,Aquino",
        				
        					"Dog,Cat,Squerrel,Birds,Mouse",
        					"Asus,Lenovo,HP,Dell,MSI",
        					"Sight,Hear,Smell,Taste,Touch"};
        					
    public void displayQuiz(){ 
    	userAnswer = "";//initial user input to none
    	checkPerQuiz = 0;//checks the answers per loop.
    	amount = (int)(Math.random()*6); // used to determine the amount of cycles of getting a random string in Questions[] array.
        
        Integer randomQandA = r.nextInt(6);//used to determine the amount of cycles of getting a random string in Answers[] array.
        
        while(doneQuestion.indexOf(String.valueOf(randomQandA)) != -1){
        	randomQandA = r.nextInt(6);//used to determine the amount of cycles of getting a random string in Answers[] array.
        }
        
        list = Questions[randomQandA]; //The variable I would like to use to store all of the randomly picked strings
        txtQuest.setText(list); //this is how I want to output the list variable.
        txtQuest.setEditable(false);
        
        listA = Answers[randomQandA];//variable use to store all of the answers of the question.
        CorrectAnswer = CorrectAnswers[randomQandA];//comparesion of correct answers
        String[] split = listA.split(",");//separate string in an array.
        b1.setText(split[0]);
        b2.setText(split[1]);
        b3.setText(split[2]);
        b4.setText(split[3]);
        b5.setText(split[4]);
        b6.setText(split[5]);
        
        changemoney(moneyCounter++);//increament offer money of the game
        
        
        doneQuestion += "," + randomQandA.toString();//dili na mu balik ang question.
    }
        
    
    public Quiz() {
    //	ImageIcon pics = new ImageIcon(Test.class.getResource("boom.gif").getFile());
    //	ImageIcon pics = new ImageIcon ("C:/Users/CJ Pamisa/Desktop/Trivia/kaboom1.png");
    	f = new JFrame();
    	f.setVisible(false);
   		f.setSize(350,250);
   		//f.setBackground(pics);
    	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	f.setLocationRelativeTo(null);
    	f.setLayout(null);
    	//f.setResizable(false);
    	
        ImageIcon picT = new ImageIcon("C:/Users/CJ Pamisa/Desktop/Trivia/kaboom1.png");
        ImageIcon img = new ImageIcon("C:/Users/CJ Pamisa/Desktop/Trivia/questioning.png");
        lblTitle = new JLabel(picT);
        lblS = new JLabel("Offer: ");
        lblCor = new JLabel("");
        lblOff = new JLabel("");
        lblE = new JLabel("");
        lblIns = new JLabel("Choose 5 answers to proceed Next Level");
        lblTri= new JLabel("");
        //lblP = new JLabel(pics);
        lblBg =new JLabel(img);

        txtQuest = new JTextArea();
       	lblTries = new JLabel("Your Money: ");

		
        b1 = new JButton("");
        b2 = new JButton("");
        b3 = new JButton("");
        b4 = new JButton("");
        b5 = new JButton("");
        b6 = new JButton("");

      //  bNG = new JButton("New Game");
        bIns = new JButton("Next Level");
        bQuit = new JButton("Quit");
        bStart = new JButton("Start");
        
        setLayout(null);
        setSize(900,500);
        setVisible(true);
        setTitle("KABOOM by: Pams");
        
        
        //setBounds(x,y,width,height);
        add(lblTitle);
        lblTitle.setBounds(95,160,200,100);
        lblTitle.setForeground(new Color(239,24,7));  //set the text color
       lblTitle.setVisible(false);
        
        add(lblTri);
        lblTri.setBounds(520,430,120,25);
        lblTri.setFont(new Font("Courier New",Font.BOLD, 20));
        
        add(lblTries);
        lblTries.setBounds(390,430,150,25);
        lblTries.setFont(new Font("Courier New",Font.BOLD, 20));
        
        add(lblS);
        lblS.setBounds(160,430,200,25);
        lblS.setFont(new Font("Courier New",Font.BOLD, 20));
        lblS.setForeground(new Color(239,24,7));
        
        add(lblOff);
        lblOff.setBounds(230,430,200,25);
        lblOff.setFont(new Font("Courier New",Font.BOLD, 20));
        lblOff.setForeground(new Color(239,24,7));
        
        add(b1);
        b1.setBounds(120,290,145,30);
        b1.setFont(new Font("Courier New",Font.BOLD,15));
        b1.setBackground(Color.GREEN);
        
        
        add(b2);
        b2.setBounds(120,330,145,30);
        b2.setFont(new Font("Courier New",Font.BOLD,15));
        b2.setBackground(Color.GREEN);
        
        add(b3);
        b3.setBounds(280,290,145,30);
        b3.setFont(new Font("Courier New",Font.BOLD,15));
        b3.setBackground(Color.GREEN);
        
        add(b4);
        b4.setBounds(280,330,145,30);
        b4.setFont(new Font("Courier New",Font.BOLD,15));
        b4.setBackground(Color.GREEN);
        
        add(b5);
        b5.setBounds(430,290,145,30);
        b5.setFont(new Font("Courier New",Font.BOLD,15));
        b5.setBackground(Color.GREEN);
        
        add(b6);
        b6.setBounds(430,330,145,30);
        b6.setFont(new Font("Courier New",Font.BOLD,15));
        b6.setBackground(Color.GREEN);
        
        add(lblCor);
        lblCor.setBounds(650,300,180,50);
        lblCor.setFont(new Font("Courier New",Font.BOLD,25));
        lblCor.setForeground(new Color(214,18,12));
        
        
        add(txtQuest);
        txtQuest.setBounds(50,60,390,50);
        txtQuest.setFont(new Font("Courier New",Font.BOLD,15));
        txtQuest.setBackground(Color.WHITE);
        
        add(lblIns);
        lblIns.setBounds(190,400,350,30);
        lblIns.setFont(new Font("Curier New",Font.BOLD, 15));
        lblIns.setForeground(new Color(0,0,0));
        
       // add(bNG);
       // bNG.setBounds(0,390,150,30);
       // bNG.setFont(new Font("Courier New",Font.BOLD,18));
       // bNG.setForeground(new Color(138,66,54));
     
        add(bQuit);
        bQuit.setBounds(660,390,150,30);
        bQuit.setFont(new Font("Courier New",Font.BOLD,18));
        bQuit.setForeground(new Color(138,66,54));
        
        
        add(bIns);
        bIns.setBounds(0,425,150,30);
        bIns.setFont(new Font("Courier New",Font.BOLD,18));
        bIns.setForeground(new Color(138,66,54));
        
        add(bStart);
        bStart.setBounds(660,425,150,30);
        bStart.setFont(new Font("Courier New",Font.BOLD, 18));
        bStart.setForeground(new Color(138,66,54));
        
        add(lblBg);
        lblBg.setBounds(0,0,900,500);
        
        add(lblE);
        
        b1.addActionListener(this);
        b2.addActionListener(this); 
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this); 
        b6.addActionListener(this);
        //bNG.addActionListener(this);
        bIns.addActionListener(this); 
        bQuit.addActionListener(this);
        bStart.addActionListener(this);
        
        
    }
    
     public void actionPerformed (ActionEvent e){
         
    
//	    if (e.getSource()==bNG) {
//	    	JOptionPane.showConfirmDialog(null,"Are you sure");
//	    		
//	            bNG.setEnabled(true);
//	            bQuit.setEnabled(true);
//	        	restart();
//	        	displayQuiz();
//	      
//	        }//end of bNewGame
	        
	    if(e.getSource()==bIns){
	    	//System.out.println(moneyCounter);
	    	if(checkPerQuiz == 5){
	    	//	int x;
	    	//	x = lblOff.getText();
			lblTri.setText(lblOff.getText());
	    //	lblTri.setText(lblOff.getText());
	    		//.setText(Integer.valueOf(lblTri.getText())+Money[moneyCounter-1]);
	    	}
	    	lblTitle.setVisible(false);
	    	bIns.setEnabled(false);
	    	displayQuiz();
	    	restart();
	
	    	}
	    	
        if (e.getSource()==bQuit) {
            JOptionPane.showMessageDialog(null,"Thank you for playing");
            System.exit(0);
        	}//end of bQuit
        
        if (e.getSource()==bStart){
        	
        	bIns.setEnabled(false);
        	bStart.setEnabled(false);
        	//bNG.setEnabled(false);
        	lblOff.setText(""+ Money[money]);
        	displayQuiz();
        		
        }//end of Start
        
        if(e.getSource()==b1){
        	if(bb1=="green"){
        		Ans[5]="6";
        		b1.setBackground(Color.RED);
        		bb1="red";
//        		ba1="locked";
        		userAnswer = b1.getText() +",";
        		if(check1()){
        			lblCor.setText("Correct !!!");
        		
        		}
        		else{
        			lblTitle.setVisible(true);
        			lockAns();
        		}	
        	}
      	
        }//end of b1
        
        if(e.getSource()==b2){
        	if(bb2=="green"){
        		Ans[4]="5";
        		b2.setBackground(Color.RED);
        		bb2="red";
        	//	ba2="locked";
        		userAnswer = b2.getText() +",";
        		if(check1()){
        			lblCor.setText("Correct !!!");
        			
        		}
        		else{
        			lblTitle.setVisible(true);
        			lockAns();
        		}
        	}
        	
        }//end of b2
        
        if(e.getSource()==b3){
        	if(bb3=="green"){
        		Ans[3]="4";
        		b3.setBackground(Color.RED);
        		bb3="red";
        //		ba3="locked";
        		userAnswer = b3.getText() +",";
        		if(check1()){
        			lblCor.setText("Correct !!!");
        		
        		}
        		else{
        			lblTitle.setVisible(true);
        			lockAns();
        		}
        	}
        	
        }//end of b3
        
        if(e.getSource()==b4){
        	if(bb4=="green"){
        		Ans[2]="3";
        		b4.setBackground(Color.RED);
        		bb4="red";
        //		ba4="locked";
        		userAnswer = b4.getText() +",";
        		if(check1()){
        			lblCor.setText("Correct !!!");
        		
        		}
        		else{
        			lblTitle.setVisible(true);
        			lockAns();
        		}
        	}
        	
        }//end of b4
        
        if(e.getSource()==b5){
        	if(bb5=="green"){
        		Ans[1]="2";
        		b5.setBackground(Color.RED);
        		bb5="red";
        //		ba5="locked";
        		userAnswer = b5.getText() +",";
        		if(check1()){
        			lblCor.setText("Correct !!!");
        		
        		}
        		else{
        			lblTitle.setVisible(true);
        			lockAns();
        		}
        	}
        	
        }//end of b5
        
        if(e.getSource()==b6){
        	if(bb6=="green"){
        		Ans[0]="1";
        		b6.setBackground(Color.RED);
        		bb6="red";
        //		ba6="locked";
        		userAnswer = b6.getText() +",";
        		if(check1()){
        			lblCor.setText("Correct !!!");
        		}
        		else{
        			lblTitle.setVisible(true);
        			lockAns();
        		}
        	}
        }//end of b6
                
    
    }//end of event handlers/functionality
    
    public boolean check1(){ // validate user answer true or false.
    	String[] split = CorrectAnswer.split(",");
    	boolean correct = false;
    	
    	for( int x=0; x<5; x++ ){
    		if(userAnswer.indexOf(split[x]) != -1){
    			correct = true;
    			checkPerQuiz++;
    		}//checks the answer per quiz.
    		bIns.setEnabled(true);
		}
		return correct;
    }
    
    public void check(){ // display validated valued user answer
    	Integer isCheck = 0;
	    	checkPerQuiz = 0;
	    	//System.out.println(CorrectAnswer);
	    	//System.out.println(userAnswer);
	    	String[] split = CorrectAnswer.split(",");
	    	//System.out.println(split.length);
	    	
    		for( int x=0; x<5; x++ ){
	    		if(userAnswer.indexOf(split[x]) != -1){
	    			checkPerQuiz++;
	    		}//checks the answer per quiz.
    		}
	    	
//	    	if(checkPerQuiz == 5){
//	    		moneyCounter += money++;
//	    		lblTri.setText(""+ Money[money]);
//	    	}
	    	
	    	displayQuiz();
	    	lockAns();
        	restart();
    }
    
    public void changemoney(int money){
       if(money==1){
           lblOff.setText("50,000");
       }
       else if(money==2){
           lblOff.setText("30,000");
       }
       else if(money==3){
           lblOff.setText("20,000");
       }
       else if(money==4){
           lblOff.setText("60,000");
       }
       else if(money==5){
           lblOff.setText("10,000");
       }
       else if(money==6){
           lblOff.setText("40,000");
       }
       else if(money==7){
          lblOff.setText("70,000");
       }
       else{
           lblOff.setText("80,000");
       }
   }
    
    public void lockAns(){
    	b1.setEnabled(false);
    	b2.setEnabled(false);
    	b3.setEnabled(false);
    	b4.setEnabled(false);
    	b5.setEnabled(false);
    	b6.setEnabled(false);	
    }
    
    public void restart(){
    	b1.setEnabled(true);
    	b1.setBackground(Color.GREEN);
    	bb1 = "green";
    	b2.setEnabled(true);
    	b2.setBackground(Color.GREEN);
    	bb2 = "green";
    	b3.setEnabled(true);
    	b3.setBackground(Color.GREEN);
    	bb3 = "green";
    	b4.setEnabled(true);
    	b4.setBackground(Color.GREEN);
    	bb4 = "green";
    	b5.setEnabled(true);
    	b5.setBackground(Color.GREEN);
    	bb5 = "green";
    	b6.setEnabled(true);
    	b6.setBackground(Color.GREEN);
    	bb6 = "green";
    }
    
    public static void main(String[] args) {
        Quiz SG = new Quiz();
        SG.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
    }
   
}
